"""
Definition of models.
"""

from django.db import models

# Create your models here.
