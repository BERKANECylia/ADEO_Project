"""
Package for the application.
"""
