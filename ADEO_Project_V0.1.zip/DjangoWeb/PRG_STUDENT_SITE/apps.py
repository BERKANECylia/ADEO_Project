from django.apps import AppConfig


class PrgStudentSiteConfig(AppConfig):
    name = 'PRG_STUDENT_SITE'
