from django.contrib import admin
from .models import PRG_STUDENT_SITE
#from DjangoWeb.PRG_STUDENT_SITE.models import models
admin.register(PRG_STUDENT_SITE)
# Register your models here.

